This is a hello world popup tutorial for Kodi.

It is meant to be used as a guide to making your first Kodi Add-on.

============
Installation
============

Launch Kodi >> Add-ons >> Get More >> .. >> Install from zip file

Feel free to ask any questions on the Kodi Forums.

Enjoy!