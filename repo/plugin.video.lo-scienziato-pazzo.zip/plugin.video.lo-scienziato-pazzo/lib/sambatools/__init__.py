# -*- coding: utf-8 -*-

import os
import sys

sys.path.append(os.path.join(os.path.dirname(__file__), 'python3' if sys.version_info[0] >= 3 else 'python2'))
